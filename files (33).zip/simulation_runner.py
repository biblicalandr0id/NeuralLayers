from neural_system import BrainSystemSimulator
import matplotlib.pyplot as plt
import numpy as np

def run_optimized_simulation():
    # Initialize simulator
    simulator = BrainSystemSimulator()
    
    # Run simulation for 24 hours
    solution = simulator.simulate()
    
    # Calculate efficiency metrics
    metrics = simulator.get_efficiency_metrics(solution)
    
    # Plot results
    plt.figure(figsize=(15, 10))
    
    # Plot key components
    plt.subplot(311)
    plt.plot(solution.t, solution.y[0], label='Pineal')
    plt.plot(solution.t, solution.y[3], label='Cerebellum')
    plt.legend()
    plt.title('Brain Region Activity')
    
    plt.subplot(312)
    plt.plot(solution.t, metrics['synchronization'], label='Sync')
    plt.legend()
    plt.title('System Synchronization')
    
    plt.subplot(313)
    plt.plot(solution.t, metrics['energy_consumption'], label='Energy')
    plt.legend()
    plt.title('Energy Consumption')
    
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    run_optimized_simulation()