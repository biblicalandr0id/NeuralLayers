import torch
import matplotlib.pyplot as plt
from unified_neural_layer import UnifiedNeuralLayer
from datetime import datetime

def run_unified_simulation(duration_hours=24):
    # Initialize the unified layer
    model = UnifiedNeuralLayer()
    
    # Create time series data
    timestamps = torch.linspace(0, duration_hours, 100)
    batch_size = 32
    input_data = torch.randn(batch_size, 9, 9)  # Random initial state
    
    # Storage for metrics
    energy_metrics = []
    states = []
    
    # Run simulation
    for t in timestamps:
        # Forward pass
        state = model(input_data)
        states.append(state.detach())
        
        # Get metrics
        metrics = model.get_energy_metrics()
        energy_metrics.append(metrics)
        
        # Update input with new state
        input_data = state[:, :9, :9]  # Use previous state as new input
    
    return states, energy_metrics

def plot_results(states, metrics):
    plt.figure(figsize=(15, 10))
    
    # Plot energy levels
    plt.subplot(311)
    energy_values = [m['total_energy'] for m in metrics]
    plt.plot(energy_values, label='Total Energy')
    plt.title('System Energy Levels')
    plt.legend()
    
    # Plot mean activation
    plt.subplot(312)
    activation_values = [m['mean_activation'] for m in metrics]
    plt.plot(activation_values, label='Mean Activation')
    plt.title('System Activation')
    plt.legend()
    
    # Plot peak activity
    plt.subplot( ▋